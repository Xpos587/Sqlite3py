'''
Module sqlite3py provides you very easy smart requests for sqlite database.
'''

from .databaseManager import Database

__author__ = 'Xpos587'
__version__ = '2.5.0'
__email__ = 'x30827pos@gmail.com'