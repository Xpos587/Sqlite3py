'''
Module sqlite3py provides you smart requests for sqlite database.
'''

from .databaseManager import Database

__author__ = 'Xpos587'
__version__ = '1.0.2'
__email__ = 'x30827pos@gmail.com'